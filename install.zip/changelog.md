# V3-12.03.2022
- Introduced GED Modules of Realme 3
- Enabled GED Boost Amp
- Enabled GED Boost Extra
- Enabled GED Boost GPU
- Enabled GED Boost CPU
- Enabled GED Self game force detect
- Increased GED CPU idle
- Increased GED CPU Boost Policy
- Disabled GED Force MDP
- Enabled GED boost
- Increased Smart GED boost
- Enabled GED GX force mode
- Enabled GED GX boost
- Enabled CPU CCI mode
- Added Refresh Rate Config
- Dropped Enable Camera HAL 3 (found issue for third party camera like TrCamera)
- Dropped Reduced Read a head and NR requests to 128kb
- Fix Beluga Touch Booster on init.d

# V2-11.20.2022
```On Source```
* Fix some props and services
* Added sepolicy.sh
* Added Thermal Config for apps and games
* Dropped Lock GPU Frequency to 800Mhz due to causing battery draining and overheating

```On System```
* Introduced Beluga Performance, Beluga Touch, Tune2fs Binaries
* Introduced Beluga Touch Booster and System Thermal Config
* Introduced Thermal Libs, Thermal Engine, and Beluga Extentions

```On Props```
* Increased LCD Density to 460
* Enabled DFPS and Smart DFPS
* Enabled Camera HAL3
* Enabled EPDG Support
* Switched Dalvik Lib2 to Libart.so
* Disabled Thermal by props
* Improve Touch Tweaks (For better Responsiveness and Speed)
* Enabled Zygote Preload
* Enabled Quickstart Support
* Improved Gaming Experience
* Disabled Background Blurr
* Improved RAM Management
* Enabled Low RAM Tweaks
* Enabled Memory Properties
* Added Dalvik Virtual Machine Tweaks
* Added Video Acceleration and improved streaming
* Reduced Wifi scanning rate to 180
* Enabled Render UI with GPU
* Disabled Automatic error reports, error profiler, strict mode checking
* Disabled Sending usage data to google
* Disabled Locating
* Disabled Vsync and CPU Vsync
* Disabled Logcat
* Many under the hood added and changes

```On Service```
* Stopped LogD, ThermalD, PerfD
* FSTrim Cache, System, Data
* Switched CPU Mode to Sports Mode
* Enabled Oppo TP Direction
* Disabled Oppo TP Limit
* Disabled CABC
* Disabled CCCI Debug
* Enabled GED GX Game Mode
* Enabled GED GX Force CPU Boost
* Switched HMP to EAS
* Increased Schedutil Downrate Limit
* Disabled Schedutil Uprate Limit
* Disabled CPU Background
* Reduced CPU System Background and Restricted
* Switched IRQ Affinity to Silvee Cluster
* Reduced Read a head and NR requests to 128kb
* Switched Scheduler to CFQ
* Block I/O Cgroups Tweaks
* Thermal Threshold temperature to 60
* Disabled CPU notify on migrate
* Enabled CPU Boost
* Added I/O Scheduler Tweaks
* Added KSM Tweaks
* Increased Dalvik Virtual Machine heap minimum free to 2m
* Added Google Tweaks
* Enabled DFPS and Smart DFPS
* Enabled Power HAL Sports Mode
* Many under the hood added and changes

```Game List of Added Thermal Config and Power HAL (Sport Mode)```
* Call of Duty Mobile (Garena and Activision)
* PUBG (All Regions)
* Mobile Legends Bang Bang
* League of Legends Wildrift
* Genshin Impact
* Sausage Man
* Freefire (All Regions)
* Roblox

```App List of Added Thermal Config and Power HAL (Sport Mode)```
* Google Chrome
* Google Classroom
* Google Docs
* Google Drive
* Google Gmail
* Google Keep
* Google Meet
* Google Play Store
* YouTube
* TrCamera
* Instagram
* Facebook
* Messenger
* Telegram
* TikTok

# V1-11.08.2022
* Initial Release
