<h1 align="center">Beluga Magisk Module (Realme 3/3i)</h1>


<div align="center">
  <strong>This module improve and enhance your gaming experience including CPU, GPU, Touch Responsiveness, Kernel Tweaks, Google Tweaks, System Tweaks, Dalvik Tweaks, and more🙂

<div align="center">
  <h3>
    <a href="https://github.com/AkasTKzume69/Beluga-Magisk-Module-Realme-3-3i/blob/master/changelog.md">
      Changelog
    </a>
    <span> | </span>
    <a href="https://github.com/AkasTKzume69/Beluga-Magisk-Module-Realme-3-3i/blob/master/installation.md">
      Installation and Guide
    </a>
    <span> | </span>
    <a href="https://sourceforge.net/projects/akastkzume-files/files/Beluga%20Magisk%20Module%20Realme%203-3i/">
      Download
    </a>
    <span> | </span>
    <a href="https://t.me/belugarealme3official">
      Support Group
    </a>
  </h3>
</div>

<div align="center">
  <!-- Latest Version -->
    <img src="https://img.shields.io/badge/Latest Version-3 Gen 1-green.svg?longCache=true&style=popout-square"
      alt="Version" />
  <!-- Last Updated -->
    <img src="https://img.shields.io/badge/Last Updated-December 13, 2022-blue.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" />
  <!-- Minimum Magisk Version -->
    <img src="https://img.shields.io/badge/Minimum Magisk Version-23-red.svg?longCache=true&style=flat-square"
      alt="_time_stamp_" /></div>
