# Warning⚠️
* Your warranty is now void.
* I am not responsible for bootloop and bricked devices, dead SD cards, thermonuclear war, or you getting fired because the alarm app failed.
* Please do some research if you have any concerns about features included in this module before installing or flashing it! You are choosing to make these modifications, and if you point the finger at me for messing up your device, I will laugh at you.
# Installation
* Remove first all module that contains all mentioned in the description. It may conflict/nuked and possible to messed up your device.
* Flash through magisk only.
* Reboot required.
